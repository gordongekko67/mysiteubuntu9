from django.shortcuts import render, get_object_or_404, HttpResponseRedirect
from django.http import HttpResponse
from django.template import loader
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

from django.views.generic.detail import DetailView
from django.views.generic.list import ListView
from django.views.generic import TemplateView
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,  login, logout



from .models import Titoli2, Giornalista,  PublishedManager

from funzioni_iot.forms import FormContatto, FormTitoli, TitoliModelForm, FormRegistrazioneUser


def titoli_list(request):
    posts = Titoli2.objects.all()
    object_list = Titoli2.objects.all()
    paginator = Paginator(object_list, 3)  # 3 posts in each page
    page = request.GET.get('page')
    try:
        posts = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer deliver the first page
        posts = paginator.page(1)
    except EmptyPage:
        # If page is out of range deliver last page of results
        posts = paginator.page(paginator.num_pages)

    return render(request, 'blog/post/list.html', {'page': page, 'posts': posts})


def titoli_detail(request, year, month, day, post):
    post = get_object_or_404(Titoli2, slug=post,
                             status='published',
                             publish__year=year,
                             publish__month=month,
                             publish__day=day)
    return render(request, 'blog/post/detail.html', {'post': post})


def index(request):
    logout(request)     
    return render(request, "base.html")
    

def homep(request):
    return render(request, "index.html")
    

def hello(request):
    text = """<h1>welcome to my app !</h1>"""
    return HttpResponse(text)


def prova_django(request):
    msg = f'prova  django'
    return HttpResponse(msg, content_type='text/plain')


def index2(request):
    return render(request, "scelta.html")


def hellohome(request):
    return render(request, "homeiot.html")


def hellocontattaci(request):
    if request.method == 'POST':
        form = FormContatto(request.POST)
        if form.is_valid():
            print("il form e' valido")
            print("NomE ",  form.cleaned_data["nome"])
            print("Cognome ",  form.cleaned_data["cognome"])
            return HttpResponse("<h1> Grazie per averci contattato </h1>")

    else:
        form = FormContatto()
    context = {"form": form}
    return render(request, "contattaci.html", context)


def crea_titoli(request):
    if request.method == 'POST':
        form = TitoliModelForm(request.POST)
        if form.is_valid():
            # inserimento dati nel data base
            new_titolo = form.save()
            return HttpResponse("<h1> Grazie per aver inserito il titolo </h1>")

    else:
        form = TitoliModelForm()
    context = {"form": form}
    return render(request, "institoli.html", context)



def visuatitoli(request):
    return render(request, "contattaci.html", context)


def registrazione(request):
    if request.method == 'POST':
        form = FormRegistrazioneUser(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            email = form.cleaned_data["email"]
            password = form.cleaned_data["password"]
            User.objects.create_user(
                username=username, password=password, email=email)

            user = authenticate(username=username, password=password)
            login(request, user)
        return HttpResponseRedirect

    else:
        form = FormRegistrazioneUser()
        context = {"form": form}
        return render(request, "registrazione.html", context)


def form2(request):
    template = loader.get_template('scelta.html')
    return HttpResponse(template)


def now(request):
    msg = f'Today is '
    return HttpResponse(msg, content_type='text/plain')


def homeiot(request):
    return render(request, "scelta.html")


def base(request):
    return render(request, "base.html")


def titoli2(request):
    msg = f'prova  django Today is '
    return HttpResponse(msg, content_type='text/plain')


def home(request):
    g = []
    for gio in Giornalista.objects.all():
        g.append(gio.nome)
    response = str(g)
    print(response)
    return HttpResponse(response, content_type='text/plain')


def homeTitoli(request):
    g = []
    h = []
    for gio in Titoli2.objects.all():
        g.append(gio.codtit2)
        h.append(gio.codisintit2)
    response = str(g) + str(h)
    print(response)
    msg = f'prova  django'
    return HttpResponse(response, content_type='text/plain')


def homeTitoly(request):
    titolo = Titoli2.objects.all()
    context = {"titoli": titolo}
    print(context)

    return render(request, 'blog/post/homepage2.html', context)


def homeTitoli2(request):
    titolo = Titoli2.objects.all()
    context = {"titoli": titolo}
    print(context)

    return render(request, 'blog/post/homepage2.html', context)


def titoloDetailView(request, pk):
    titolo = Titoli2.objects.get(pk=pk)
    context = {"titoli": titolo}
    return render(request, 'blog/post/titolo_detail.html', context)

#  CBV   Class Based Views
#  Documentazione ufficiale


class TitoloDetailViewCB(DetailView):
    model = Titoli2
    template_name = "titolo_detail.html"


class AboutView(TemplateView):
    template_name = "blog/post/about2.html"


class Titoli_list_view(ListView):
    model = Titoli2
    template_name = "lista_titoli.html"


def login(request):
    username = "not logged in"

    if request.method == "POST":
        # Get the posted form
        MyLoginForm = LoginForm(request.POST)

        if MyLoginForm.is_valid():
            username = MyLoginForm.cleaned_data['username']
    else:
        MyLoginForm = Loginform()

    return render(request, 'login.html', {"username": username})


def logout_enrico(request):
    logout(request)     
    return render(request, 'logged_out.html')
