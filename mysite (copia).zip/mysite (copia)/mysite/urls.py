"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from funzioni_iot import views  as views_app_iot
from funzioni_iot.views import titoloDetailView, TitoloDetailViewCB, home
#from some_app.views import AboutView
from django.views.generic import TemplateView


urlpatterns = [
    path('admin/', admin.site.urls),
    path('index', views_app_iot.index),
    path('hello', views_app_iot.hello),
    path('hellohome', views_app_iot.hellohome),
    path('hellocontattaci', views_app_iot.hellocontattaci),
    path('creatitoli', views_app_iot.crea_titoli),
    path('visuatitoli', views_app_iot.visuatitoli),
    path('homeiot', views_app_iot.homeiot),
    path('homeTitoli', views_app_iot.homeTitoli),
    path('homeTitoly', views_app_iot.homeTitoly),
    path('homeTitolj', views_app_iot.homeTitoli2),
    path('index2', views_app_iot.index2),
    path('now', views_app_iot.now),
    path('prova_django', views_app_iot.prova_django),
    path('blog/', include('blog.urls', namespace='blog')),
    path('titoli2/', include('funzioni_iot.urls', namespace='titol')),
    path('titoli2/titolosingolo/<int:pk>', titoloDetailView, name ='titolo_detail'),
    path('about2/', include('funzioni_iot.urls', namespace='titol'))
    
]
  

urlpatterns += [
    path('', views_app_iot.homep),
    path('registrazione/', views_app_iot.registrazione),
    path('base/', views_app_iot.base),
    path('accounts/loginenrico/', views_app_iot.login),
    path('accounts/logoutenrico/', views_app_iot.logout_enrico),
    path('accounts/', include('django.contrib.auth.urls')),
]